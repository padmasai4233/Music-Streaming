document.getElementById("logout").addEventListener("click", () => {
    window.location.href = "signin.html";
});
